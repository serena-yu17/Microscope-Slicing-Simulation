--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.slice DROP CONSTRAINT slice_pkey;
ALTER TABLE ONLY public.sample DROP CONSTRAINT sample_pkey;
ALTER TABLE ONLY public.query DROP CONSTRAINT query_pkey;
ALTER TABLE public.slice ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.query ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.slice_id_seq;
DROP TABLE public.slice;
DROP TABLE public.sample;
DROP SEQUENCE public.query_id_seq;
DROP TABLE public.query;
DROP FUNCTION public.slicecountonsample(sample integer);
DROP FUNCTION public.slicecountall();
DROP FUNCTION public.combination(nv bigint, mv bigint);
DROP FUNCTION public.calcprobability();
DROP FUNCTION public.bayes(sampleradius integer, psl double precision, totalprob double precision);
DROP EXTENSION adminpack;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET search_path = public, pg_catalog;

--
-- Name: bayes(integer, double precision, double precision); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION bayes(sampleradius integer, psl double precision, totalprob double precision) RETURNS double precision
    LANGUAGE plpgsql
    AS $$
declare
   matchSampleProb real;
   rowVal record;
   sliceCount int;
   res double precision;
   countRadius bigint;
   countRadiusSample bigint;
begin   
    select sum(probability) into matchSampleProb
    from sample
    where sample = sampleRadius;
    res := matchSampleProb / totalProb;
    
    for rowVal in (select * from sliceCountOnSample(sampleRadius)) 
    loop
  		res := res * combination(rowVal.countAll, rowVal.countMatch); 
    end loop;
    
    select count(query.radius) into countRadius from query;
    select count(slice.slice) into countRadiusSample from slice where sample = sampleRadius;
    res := res / combination(countRadiusSample, countRadius);
    
   	res := res / pSL;
    return res;
end
$$;


ALTER FUNCTION public.bayes(sampleradius integer, psl double precision, totalprob double precision) OWNER TO postgres;

--
-- Name: calcprobability(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION calcprobability() RETURNS TABLE(sample numeric, probability numeric)
    LANGUAGE plpgsql
    AS $$
declare
	rowVal record;
    pSL double precision;
    totalProb double precision;
    countRadiusQ bigint;
    countRadiusS bigint;
begin
select sum(sample.probability) into totalProb
    from sample;    
pSL := 1;
for rowVal in (select * from sliceCountAll())
loop
    pSL := pSL * combination(rowVal.countAll, rowVal.countMatch);
end loop;

select count(query.radius) into countRadiusQ from query;
select count(slice.slice) into countRadiusS from slice;
pSL := pSL / combination(countRadiusS, countRadiusQ);

return QUERY 
    select cast(cast(s.sample as numeric (17, 1))/10 as numeric (17, 1)), cast(bayes(s.sample, pSL, totalProb) * 100 as numeric(14, 5))
    from query q, slice s
    where q.radius = round(s.slice/10)
    group by s.sample
    having count(distinct q.radius) >= (select count(distinct radius) from query)
    order by bayes(s.sample, pSL, totalProb) desc;
end
$$;


ALTER FUNCTION public.calcprobability() OWNER TO postgres;

--
-- Name: combination(bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION combination(nv bigint, mv bigint) RETURNS double precision
    LANGUAGE plpgsql
    AS $$
declare 
	res double precision;
    i int;
begin
	if (nv < mv) then
    	return 0;
    end if;
	res := 1;
    i := nv;
    while (i > nv-mv) loop
    	res := res * i;
        i := i-1;
    end loop;
    res := res / factorial(mv);
    return res;
end
$$;


ALTER FUNCTION public.combination(nv bigint, mv bigint) OWNER TO postgres;

--
-- Name: slicecountall(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION slicecountall() RETURNS TABLE(radius integer, countmatch bigint, countall bigint)
    LANGUAGE sql
    AS $$
	select a.radius, countMatch, countAll  
from
    (select q.radius, count(q.radius) as countMatch
    from query q
    group by q.radius) as m,
    (select q.radius, count(s.slice) as countAll
    from query q, slice s
    where round(s.slice/10) = round(q.radius)
    group by q.radius) as a
where a.radius = m.radius;
$$;


ALTER FUNCTION public.slicecountall() OWNER TO postgres;

--
-- Name: slicecountonsample(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION slicecountonsample(sample integer) RETURNS TABLE(radius integer, countmatch bigint, countall bigint)
    LANGUAGE sql
    AS $_$
	select a.radius, countMatch, countAll  
from
    (select q.radius, count(q.radius) as countMatch
    from query q
    group by q.radius) as m,
    (select q.radius, count(s.slice) as countAll
    from query q, slice s
    where round(s.slice/10) = round(q.radius)
     	and s.sample = $1
    group by q.radius) as a
where a.radius = m.radius;
$_$;


ALTER FUNCTION public.slicecountonsample(sample integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: query; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE query (
    id integer NOT NULL,
    radius integer NOT NULL
);


ALTER TABLE query OWNER TO postgres;

--
-- Name: query_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE query_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE query_id_seq OWNER TO postgres;

--
-- Name: query_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE query_id_seq OWNED BY query.id;


--
-- Name: sample; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE sample (
    sample integer NOT NULL,
    probability real NOT NULL
);


ALTER TABLE sample OWNER TO postgres;

--
-- Name: slice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE slice (
    id integer NOT NULL,
    slice integer NOT NULL,
    sample integer NOT NULL
);


ALTER TABLE slice OWNER TO postgres;

--
-- Name: slice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE slice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE slice_id_seq OWNER TO postgres;

--
-- Name: slice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE slice_id_seq OWNED BY slice.id;


--
-- Name: query id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY query ALTER COLUMN id SET DEFAULT nextval('query_id_seq'::regclass);


--
-- Name: slice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY slice ALTER COLUMN id SET DEFAULT nextval('slice_id_seq'::regclass);


--
-- Data for Name: query; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY query (id, radius) FROM stdin;
\.
COPY query (id, radius) FROM '$$PATH$$/2817.dat';

--
-- Data for Name: sample; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sample (sample, probability) FROM stdin;
\.
COPY sample (sample, probability) FROM '$$PATH$$/2815.dat';

--
-- Data for Name: slice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY slice (id, slice, sample) FROM stdin;
\.
COPY slice (id, slice, sample) FROM '$$PATH$$/2819.dat';

--
-- Name: query_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('query_id_seq', 211, true);


--
-- Name: slice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('slice_id_seq', 663833, true);


--
-- Name: query query_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY query
    ADD CONSTRAINT query_pkey PRIMARY KEY (id);


--
-- Name: sample sample_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sample
    ADD CONSTRAINT sample_pkey PRIMARY KEY (sample);


--
-- Name: slice slice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY slice
    ADD CONSTRAINT slice_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

